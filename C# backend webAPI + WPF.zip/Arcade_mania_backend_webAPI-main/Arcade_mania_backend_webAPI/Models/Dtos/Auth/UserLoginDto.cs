﻿namespace Arcade_mania_backend_webAPI.Models.Dtos.Auth
{
    public class UserLoginDto
    {
        public string Name { get; set; } = null!;
        public string Password { get; set; } = null!;
    }
}
