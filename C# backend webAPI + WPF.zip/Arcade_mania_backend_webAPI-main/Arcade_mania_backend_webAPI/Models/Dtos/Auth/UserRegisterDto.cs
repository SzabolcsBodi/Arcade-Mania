﻿namespace Arcade_mania_backend_webAPI.Models.Dtos.Auth
{
    public class UserRegisterDto
    {
        public string Name { get; set; } = null!;
        public string Password { get; set; } = null!;
    }
}
