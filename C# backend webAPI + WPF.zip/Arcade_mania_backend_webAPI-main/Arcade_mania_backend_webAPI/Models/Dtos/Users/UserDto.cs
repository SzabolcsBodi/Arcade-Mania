﻿namespace Arcade_mania_backend_webAPI.Models.Dtos.Users
{
    public class UserDto
    {
        public Guid Id { get; set; }
        public string Name { get; set; } = null!;
    }
}
